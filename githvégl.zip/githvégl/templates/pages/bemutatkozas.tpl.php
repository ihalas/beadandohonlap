﻿<h2>Kiskun Népművészeti Egyesület</h2>
<img src="./images/neptanc.jpg">
<p>Célunk a a magyar nép hagyományainak, szokásainak,a magyar népi kultúra értékeinek megőrzése, gondozása és közvetítése a gyermek-,diák-, és felnőtt korosztályok felé.Feladatunknak tartjuk gyermek- és diákközösségek, pedagógusok, városunk és a régió polgárainak, társadalmi szervezeteinek hagyományőrző-alkotó tevékenységének ösztönzését, támogatását, szolgáltatásokkal való segítését.Ennek érdekében több hagyományőrző csoportot, közösséget működtetünk, rendezvényeket szervezünk, támogatjuk más szervezetek hagyományőrző tevékenységét.</p>
<p>Az egyesület tevékenysége a fenti célok elérése érdekében:A népi kultúra értékeit bemutató fellépések, rendezvények,táncházak,
bemutatók, bemutató órák szervezése, lebonyolítása.Hagyományőrző, kézműves és egyéb manuális foglalkozások, játszóházak,
programok, táborok szervezése.Felnőtt és ifjúsági, gyermek néptánc és kézműves csoportok, műhelyek működtetése. </p>
<img src="./images/csup.jpg">
<p><a href="http://www.kiskuntancegyutteskiskunhalas.hu/index.php?link=tancegyuttes">További információ régi honlapunkon</a></p>
<h4>Csuporka felnőtt fazekas kör</h4>
<video controls width="240" height="360" >
<source src="videos/fazvid.mp4" type="video/mp4">




