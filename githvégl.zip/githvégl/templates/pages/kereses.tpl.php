<?php
<form method="get"  acton="http://google.com/search">
	<input type="text" name="q"/>
	<input type="submit" value="Keresés"/>
</form>
?>