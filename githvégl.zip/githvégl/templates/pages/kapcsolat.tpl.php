﻿<script type="text/javascript" src="js/main.js"></script>
<h2>Elérhetőségek</h2>
<p><strong>Kiskun Népművészeti Egyesület</strong> 6400, Kiskunhalas, Köztársaság u. 17.<br>képviselő: Morvainé Kovács Ibolya, telefon: 06-77/422-553, e-mail:kisk@gmail.com</p>

<p><strong>Kiskun Táncegyüttes</strong> művészeti vezető: Mándity László<br>telefon: 06-70-213 5634</p>
<h2>Kapcsolat</h2>
    <form name="kapcsolat" action="kuldes.php" onsubmit="return ellenoriz();" method="post">
        <div>
            <label><input type="text" id="nev" name="nev" size="20" maxlength="40">Név (minimum 5 karakter): </label>
            <br/>
            <label><input type="text" id="email" name="email" size="30" maxlength="40">E-mail (kötelező): </label>
            <br/>
            <label> <textarea id="szoveg" name="szoveg" cols="35" rows="7"></textarea> Üzenet (kötelező): </label>
            <br/>
            <input id="kuld" type="submit" value="Küld">
            <button onclick="ellenoriz();" type="button">Ellenőriz</button>
        </div>
    </form>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d4120.424221165229!2d19.479771188919415!3d46.42781693138002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1shu!2shu!4v1555857542405!5m2!1shu!2shu" width="300" height="225" frameborder="0" style="border:0" allowfullscreen></iframe>
<br>
<a target="_blank" href="https://www.google.hu/maps/place/Pallasz+Ath%C3%A9n%C3%A9+Egyetem+GAMF+Kar/@46.8960799,19.6669509,17z/data=!3m1!4b1!4m5!3m4!1s0x4743da7a6c479e1d:0xc8292b3f6dc69e7f!8m2!3d46.8960763!4d19.6691396?hl=hu">Nagyobb térkép</a>

