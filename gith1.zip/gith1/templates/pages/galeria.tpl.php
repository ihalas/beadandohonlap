﻿<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
 
    </head>
    <body>
     	<form action="upload_file.php" method="post"
    enctype="multipart/form-data">
    <label for="file"></label>
    <input type="file" name="file" id="file">
     <br>
    <input type="submit" name="submit" value="feltölt">
  </form>
<?php
if ($_FILES["file"]["error"] > 0) {
  echo "Error: " . $_FILES["file"]["error"] . "<br>";
} else {
  echo "Upload: " . $_FILES["file"]["name"] . "<br>";
  echo "Type: " . $_FILES["file"]["type"] . "<br>";
  echo "Size: " . ($_FILES["file"]["size"] / 1024) 
       . " Kb<br>";
  echo "Stored in: " . $_FILES["file"]["tmp_name"];
}
if ((($_FILES["file"]["type"] == "image/gif")
    || ($_FILES["file"]["type"] == "image/pjpeg"))
      && ($_FILES["file"]["size"] < 160000)) {
  if ($_FILES["file"]["error"] > 0) {
    echo "Error: " . $_FILES["file"]["error"] . "<br>";
  } else {
    echo "Upload: " . $_FILES["file"]["name"] . "<br>";
    echo "Type: " . $_FILES["file"]["type"] . "<br>";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) 
         . " Kb<br>";
    echo "Stored in: " . $_FILES["file"]["tmp_name"];
  }
} else {
  echo "Invalid file";
}
if (($_FILES["file"]["type"] == "image/gif")
      || ($_FILES["file"]["type"] == "image/pjpeg")
    && ($_FILES["file"]["size"] < 160000)) {
  if ($_FILES["file"]["error"] > 0) {
    echo "Return Code: " . $_FILES["file"]["error"] 
         . "<br>";
  } else {
    echo "Upload: " . $_FILES["file"]["name"] . "<br>";
    echo "Type: " . $_FILES["file"]["type"] . "<br>";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) 
         . " Kb<br>";
    echo "Temp file: " . $_FILES["file"]["tmp_name"] 
         . "<br>";
    if (file_exists("upload/" . $_FILES["file"]["name"])) {
      echo $_FILES["file"]["name"] . " already exists. ";
    } else {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "upload/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "upload/" 
           . $_FILES["file"]["name"];
    }
  }
} else {
  echo "Invalid file";


}

    $mappanev = "upload" ;

    $mappa = opendir($mappanev) ;
    while( $fajl = readdir($mappa) )
    {
	$t = strtolower(substr( $fajl , -4 )) ;

	if( $t==".jpg" || $t=="jpeg" || $t==".png" || $t==".gif" )
	{
	   print "
	      <div class='kiskep'>
	         <a href='$mappanev/$fajl'><img src='$mappanev/$fajl'></a>
	      </div>
	   " ;
	}
    }
    closedir($mappa) ;
?>  
    </body>  
</html








   
