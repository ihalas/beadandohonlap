﻿<h2> Kiskun Táncegyüttes</h2>
<img src="./images/knepm.jpg">
<p>A táncegyüttes 2008 őszén alakult a kiskunhalasi művészeti iskola végzős növendékeiből.
A csoport tagjai középiskolás és egyetemista diákok és dolgozó fiatalok.
A tánccsoport a regionális minősítő fesztiválon ezüst és bronz minősítést szerzett csoportos kategóriában, a táncosok szólistaként arany, ezüst és bronz minősítéseket szereztek.
Az együttes fő célja a néptánc hagyományok ápolása, gyűjtése és színpadra állítása a Kárpát-medence táncaiból. Emellett kiemelt fontossággal bír a szűkebb környezetünk Kiskunhalas és a Dél-Alföld hagyományainak, szokásainak táncainak gyűjtése, ápolása és továbbadása a következő generációk számára.</p>
<p>Utánpótlásunk fő bázisát a Kiskunhalasi Alapfokú Művészeti Iskola néptánc tagozatos diákjai alkotják. 
A Művészeti Iskola művészeti ágai között 2003  óta szerepel a néptánc.
<img src="./images/mandity.jpg">
A gyerekek tantervben meghatározott követelmények szerint az életkori sajátosságaikat figyelembe véve, felmenő rendszerben  részesülnek az oktatásban.  A népi gyerekjátékoktól kezdve a későbbi önálló táncolás és motívum szerkesztés, önálló táncalkotás elsajátításáig.
Jelenleg a gyerekek 7 éves kortól középiskolás korig tanulnak néptáncot 5 évfolyamon, több mint 60 fővel.
A Kiskun Táncegyüttes koreográfusa és művészeti vezetője, valamint a Művészeti Iskola néptánc tanszakának tanszakvezetője: Mándity László néptáncpedagógus.</p>
<iframe width="280" height="160" src="https://www.youtube.com/embed/rjpurL96mAU" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>