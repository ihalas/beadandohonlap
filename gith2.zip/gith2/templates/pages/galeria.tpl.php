﻿<h2>Képgaléria</h2>
<?php
    $mappanev = "uploads" ;

    $mappa = opendir($mappanev) ;
    while( $fajl = readdir($mappa) )
    {
	$t = strtolower(substr( $fajl , -4 )) ;

	if( $t==".jpg" || $t=="jpeg" || $t==".png" || $t==".gif" )
	{
	   print "
	      <div class='kiskep'>
	        <a href='$mappanev/$fajl'><img src='$mappanev/$fajl'></a>
	      </div>
	   " ;
	}
    }
    closedir($mappa);
?>
<form enctype="multipart/form-data" action="" method="post" />
<input type="hidden" name="MAX_FILE_SIZE" value="3000000" /> <!--a feltöltött file maximális mérete 3mb-->
<label for="file"> Válassz egy fájlt!</label><input id="file" type="file" name="file" />
<input type="submit" name="submit" value="Feltöltés" />









   
